class Producto{
    producto;
    categoria;
    stock;
    precio;

    contructor (producto, categoria, stock, precio){
        this.producto = producto;
        this.categoria = categoria;
        this.stock = stock;
        this.precio = precio;
    }
}
